from django.shortcuts import render
from testapp1.models import client,project
from rest_framework import viewsets
from testapp1.serializer import clientserializer,projectserializer
# Create your views here.
class Client_View_set(viewsets.ModelViewSet):
    queryset=client.objects.all()
    serializer_class=clientserializer

class project_View_set(viewsets.ModelViewSet):
    queryset=project.objects.all()
    serializer_class=projectserializer
