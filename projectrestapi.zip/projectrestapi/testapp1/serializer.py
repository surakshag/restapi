from rest_framework import serializers
from testapp1.models import client,project

class clientserializer(serializers.ModelSerializer):
    class Meta:
        model=client
        fields="__all__"

class projectserializer(serializers.ModelSerializer):
    client=clientserializer(many=True,read_only=True)
    class Meta:
        model=project
        fields="__all__"
