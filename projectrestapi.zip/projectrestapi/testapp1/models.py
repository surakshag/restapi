from django.db import models

# Create your models here.
class project(models.Model):
    project=models.CharField(max_length=100)


class client(models.Model):
    project1=models.ForeignKey(project,on_delete=models.CASCADE)
    Client_name=models.CharField(max_length=100)
    Created_at=models.DateTimeField(auto_now=True)
    Created_by=models.CharField(max_length=100)
